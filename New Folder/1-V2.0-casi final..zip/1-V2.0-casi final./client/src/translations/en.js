export default {
  // Header Navigation
  nav: {
    home: 'Home',
    services: 'Services',
    portfolio: 'Portfolio',
    about: 'About Us',
    dashboard: 'Dashboard',
    myPanel: 'My Panel',
    login: 'Login',
    logout: 'Logout',
    register: 'Register'
  },
  
  // User roles
  roles: {
    admin: 'Administrator',
    client: 'Client'
  },
  
  // Theme toggle
  theme: {
    lightMode: 'Enable light mode',
    darkMode: 'Enable dark mode'
  },
  
  // Accessibility
  accessibility: {
    openMenu: 'Open navigation menu',
    closeMenu: 'Close navigation menu',
    selectLanguage: 'Select language'
  },
  
  // Common elements
  common: {
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    cancel: 'Cancel',
    save: 'Save',
    edit: 'Edit',
    delete: 'Delete',
    confirm: 'Confirm',
    close: 'Close'
  },
  
  // Home page
  home: {
    title: 'Welcome to Borderless Techno Company',
    subtitle: 'Technology solutions without borders',
    description: 'We transform ideas into digital reality with our web development, mobile applications and technology consulting services.',
    getStarted: 'Get Started',
    learnMore: 'Learn More'
  },
  
  // Services page
  services: {
    title: 'Our Services',
    webDevelopment: 'Web Development',
    mobileDevelopment: 'Mobile Development',
    consulting: 'Tech Consulting',
    description: 'We offer a wide range of technology services'
  },
  
  // Portfolio page
  portfolio: {
    title: 'Our Portfolio',
    projects: 'Projects',
    viewProject: 'View Project'
  },
  
  // About page
  about: {
    title: 'About Us',
    mission: 'Our Mission',
    vision: 'Our Vision',
    values: 'Our Values',
    description: 'We are a technology company specialized in web development and digital solutions.',
    teamTitle: 'Our Team',
    experience: 'Years of Experience',
    projects: 'Completed Projects',
    clients: 'Satisfied Clients'
  },

  // Contact page
  contact: {
    title: 'Contact',
    subtitle: 'Get in touch with us',
    name: 'Name',
    email: 'Email',
    message: 'Message',
    send: 'Send',
    phone: 'Phone',
    address: 'Address',
    followUs: 'Follow Us'
  },

  // Login page
  login: {
    title: 'Login',
    email: 'Email',
    password: 'Password',
    loginButton: 'Login',
    noAccount: "Don't have an account?",
    createAccount: 'Create account',
    forgotPassword: 'Forgot your password?'
  },

  // Dashboard
  dashboard: {
    welcome: 'Welcome',
    overview: 'Overview',
    statistics: 'Statistics',
    recentActivity: 'Recent Activity',
    quickActions: 'Quick Actions',
    notifications: 'Notifications',
    profile: 'Profile',
    settings: 'Settings'
  },

  // Client Panel
  clientPanel: {
    myProjects: 'My Projects',
    activeProjects: 'Active Projects',
    completedProjects: 'Completed Projects',
    invoices: 'Invoices',
    payments: 'Payments',
    support: 'Support',
    newRequest: 'New Request'
  },

  // Admin specific
  admin: {
    clientManagement: 'Client Management',
    projectManagement: 'Project Management',
    financialReports: 'Financial Reports',
    systemSettings: 'System Settings',
    userActivity: 'User Activity',
    analytics: 'Analytics'
  },

  // Forms
  forms: {
    required: 'Required field',
    invalidEmail: 'Invalid email',
    passwordTooShort: 'Password too short',
    confirmPassword: 'Confirm password',
    passwordsDoNotMatch: 'Passwords do not match',
    submit: 'Submit',
    reset: 'Reset',
    search: 'Search'
  },

  // Status
  status: {
    pending: 'Pending',
    inProgress: 'In Progress',
    completed: 'Completed',
    cancelled: 'Cancelled',
    active: 'Active',
    inactive: 'Inactive'
  }
};