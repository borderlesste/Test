
import ClientPanel from '../components/ClientPanel';

function Profile() {
  return (
    <div>
      <ClientPanel />
    </div>
  );
}

export default Profile;