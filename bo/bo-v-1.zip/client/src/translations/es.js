export default {
  // Header Navigation
  nav: {
    home: 'Inicio',
    services: 'Servicios',
    portfolio: 'Portafolio',
    about: 'Nosotros',
    dashboard: 'Dashboard',
    myPanel: 'Mi Panel',
    login: 'Iniciar Sesión',
    logout: 'Cerrar Sesión',
    register: 'Registrarse'
  },
  
  // User roles
  roles: {
    admin: 'Administrador',
    client: 'Cliente'
  },
  
  // Theme toggle
  theme: {
    lightMode: 'Activar modo claro',
    darkMode: 'Activar modo oscuro'
  },
  
  // Accessibility
  accessibility: {
    openMenu: 'Abrir menú de navegación',
    closeMenu: 'Cerrar menú de navegación',
    selectLanguage: 'Seleccionar idioma'
  },
  
  // Common elements
  common: {
    loading: 'Cargando...',
    error: 'Error',
    success: 'Éxito',
    cancel: 'Cancelar',
    save: 'Guardar',
    edit: 'Editar',
    delete: 'Eliminar',
    confirm: 'Confirmar',
    close: 'Cerrar'
  },
  
  // Home page
  home: {
    title: 'Transformamos Ideas en Soluciones Digitales',
    subtitle: 'Soluciones tecnológicas sin fronteras',
    description: 'Desarrollamos software innovador, aplicaciones web y móviles que impulsan el crecimiento de tu negocio en la era digital',
    getStarted: 'Comenzar Proyecto',
    learnMore: 'Ver Portafolio',
    servicesTitle: 'Nuestros Servicios',
    servicesSubtitle: 'Ofrecemos soluciones tecnológicas completas adaptadas a las necesidades de tu empresa',
    aboutTitle: 'Sobre Borderless Techno Company',
    aboutDescription1: 'Somos un equipo apasionado de desarrolladores, diseñadores y consultores tecnológicos especializados en crear soluciones digitales innovadoras para empresas de todos los tamaños en Latinoamérica.',
    aboutDescription2: 'Con más de 5 años de experiencia en el mercado, hemos ayudado a más de 100 empresas a transformar digitalmente sus negocios, optimizar procesos y alcanzar sus objetivos a través de la tecnología.',
    valuesTitle: 'Nuestros Valores',
    contactTitle: '¿Listo para comenzar?',
    contactSubtitle: 'Conversemos sobre tu proyecto y descubre cómo podemos ayudarte a alcanzar tus objetivos',
    formTitle: 'Envíanos un mensaje',
    contactInfoTitle: 'Información de Contacto'
  },
  
  // Services page
  services: {
    title: 'Nuestros Servicios',
    webDevelopment: 'Desarrollo Web',
    mobileDevelopment: 'Desarrollo Móvil',
    consulting: 'Consultoría Tech',
    description: 'Ofrecemos una amplia gama de servicios tecnológicos'
  },
  
  // Portfolio page
  portfolio: {
    title: 'Nuestro Portafolio',
    projects: 'Proyectos',
    viewProject: 'Ver Proyecto'
  },
  
  // About page
  about: {
    title: 'Acerca de Nosotros',
    mission: 'Nuestra Misión',
    vision: 'Nuestra Visión',
    values: 'Nuestros Valores',
    description: 'Somos una empresa tecnológica especializada en desarrollo web y soluciones digitales.',
    teamTitle: 'Nuestro Equipo',
    experience: 'Años de Experiencia',
    projects: 'Proyectos Completados',
    clients: 'Clientes Satisfechos'
  },

  // Contact page
  contact: {
    title: 'Contacto',
    subtitle: 'Ponte en contacto con nosotros',
    name: 'Nombre',
    email: 'Email',
    message: 'Mensaje',
    send: 'Enviar',
    phone: 'Teléfono',
    address: 'Dirección',
    followUs: 'Síguenos'
  },

  // Login page
  login: {
    title: 'Iniciar Sesión',
    email: 'Email',
    password: 'Contraseña',
    loginButton: 'Iniciar Sesión',
    noAccount: '¿No tienes cuenta?',
    createAccount: 'Crear cuenta',
    forgotPassword: '¿Olvidaste tu contraseña?'
  },

  // Dashboard
  dashboard: {
    welcome: 'Bienvenido',
    overview: 'Resumen',
    statistics: 'Estadísticas',
    recentActivity: 'Actividad Reciente',
    quickActions: 'Acciones Rápidas',
    notifications: 'Notificaciones',
    profile: 'Perfil',
    settings: 'Configuración'
  },

  // Client Panel
  clientPanel: {
    myProjects: 'Mis Proyectos',
    activeProjects: 'Proyectos Activos',
    completedProjects: 'Proyectos Completados',
    invoices: 'Facturas',
    payments: 'Pagos',
    support: 'Soporte',
    newRequest: 'Nueva Solicitud'
  },

  // Admin specific
  admin: {
    clientManagement: 'Gestión de Clientes',
    projectManagement: 'Gestión de Proyectos',
    financialReports: 'Reportes Financieros',
    systemSettings: 'Configuración del Sistema',
    userActivity: 'Actividad de Usuarios',
    analytics: 'Analíticas'
  },

  // Forms
  forms: {
    required: 'Campo requerido',
    invalidEmail: 'Email inválido',
    passwordTooShort: 'Contraseña muy corta',
    confirmPassword: 'Confirmar contraseña',
    passwordsDoNotMatch: 'Las contraseñas no coinciden',
    submit: 'Enviar',
    reset: 'Restablecer',
    search: 'Buscar'
  },

  // Status
  status: {
    pending: 'Pendiente',
    inProgress: 'En Progreso',
    completed: 'Completado',
    cancelled: 'Cancelado',
    active: 'Activo',
    inactive: 'Inactivo'
  },

  // Privacy Policy
  privacy: {
    title: 'Política de Privacidad',
    lastUpdated: 'Última actualización',
    date: '27 de Julio de 2025',
    introduction: {
      title: 'Introducción',
      content1: 'En Borderless Techno Company, nos comprometemos a proteger su privacidad y garantizar la seguridad de su información personal. Esta Política de Privacidad describe cómo recopilamos, utilizamos, divulgamos y protegemos su información cuando utiliza nuestros servicios.',
      content2: 'Al utilizar nuestros servicios, usted acepta las prácticas descritas en esta política. Si no está de acuerdo con estas prácticas, le recomendamos que no utilice nuestros servicios.'
    },
    collection: {
      title: 'Información que Recopilamos',
      personalInfo: {
        title: 'Información Personal',
        name: 'Nombre completo',
        email: 'Dirección de correo electrónico',
        phone: 'Número de teléfono',
        company: 'Nombre de la empresa',
        address: 'Dirección postal'
      },
      technicalInfo: {
        title: 'Información Técnica',
        ip: 'Dirección IP',
        browser: 'Tipo y versión del navegador',
        device: 'Información del dispositivo',
        cookies: 'Cookies y tecnologías similares',
        usage: 'Datos de uso del sitio web'
      }
    },
    usage: {
      title: 'Cómo Utilizamos su Información',
      services: 'Proporcionar y mejorar nuestros servicios',
      communication: 'Comunicarnos con usted sobre proyectos y servicios',
      improvement: 'Mejorar la experiencia del usuario',
      support: 'Brindar soporte técnico y atención al cliente',
      legal: 'Cumplir con obligaciones legales',
      marketing: 'Enviar comunicaciones de marketing (con su consentimiento)'
    },
    sharing: {
      title: 'Compartir Información',
      content1: 'No vendemos, intercambiamos ni transferimos su información personal a terceros, excepto en las siguientes circunstancias:',
      consent: 'Con su consentimiento explícito',
      legal: 'Para cumplir con requisitos legales',
      business: 'Con socios comerciales de confianza para prestar servicios',
      protection: 'Para proteger nuestros derechos o la seguridad de otros'
    },
    security: {
      title: 'Seguridad de los Datos',
      content1: 'Implementamos medidas de seguridad técnicas, administrativas y físicas para proteger su información personal:',
      encryption: 'Cifrado de datos en tránsito y en reposo',
      access: 'Control de acceso limitado a información personal',
      monitoring: 'Monitoreo continuo de sistemas de seguridad',
      updates: 'Actualizaciones regulares de protocolos de seguridad'
    },
    rights: {
      title: 'Sus Derechos',
      access: 'Acceder a su información personal',
      correct: 'Corregir información inexacta',
      delete: 'Solicitar la eliminación de sus datos',
      restrict: 'Restringir el procesamiento de sus datos',
      portability: 'Solicitar la portabilidad de datos',
      object: 'Oponerse al procesamiento para marketing directo'
    },
    cookies: {
      title: 'Uso de Cookies',
      content1: 'Utilizamos cookies y tecnologías similares para mejorar su experiencia:',
      essential: 'Cookies esenciales para el funcionamiento del sitio',
      analytics: 'Cookies de análisis para mejorar nuestros servicios',
      preferences: 'Cookies de preferencias para personalizar su experiencia',
      marketing: 'Cookies de marketing (con su consentimiento)'
    },
    changes: {
      title: 'Cambios a esta Política',
      content: 'Nos reservamos el derecho de actualizar esta Política de Privacidad en cualquier momento. Le notificaremos sobre cambios importantes por correo electrónico o mediante un aviso en nuestro sitio web.'
    },
    contact: {
      title: 'Información de Contacto',
      content: 'Si tiene preguntas sobre esta Política de Privacidad o desea ejercer sus derechos, puede contactarnos:',
      company: 'Empresa',
      email: 'Email',
      address: 'Dirección'
    }
  },

  // Terms of Service
  terms: {
    title: 'Términos de Servicio',
    lastUpdated: 'Última actualización',
    date: '27 de Julio de 2025',
    introduction: {
      title: 'Introducción',
      content1: 'Bienvenido a Borderless Techno Company. Estos Términos de Servicio rigen el uso de nuestros servicios de desarrollo de software, aplicaciones web, móviles y consultoría tecnológica.',
      content2: 'Al contratar nuestros servicios, usted acepta cumplir con estos términos. Si no está de acuerdo, no debe utilizar nuestros servicios.'
    },
    acceptance: {
      title: 'Aceptación de los Términos',
      content: 'Al acceder y utilizar nuestros servicios, usted confirma que ha leído, entendido y acepta estar sujeto a estos Términos de Servicio y todas las leyes y regulaciones aplicables.'
    },
    services: {
      title: 'Descripción de Servicios',
      content1: 'Borderless Techno Company proporciona los siguientes servicios:',
      webDevelopment: 'Desarrollo de aplicaciones web y sitios web',
      mobileDevelopment: 'Desarrollo de aplicaciones móviles para iOS y Android',
      backend: 'Desarrollo de backend y APIs',
      consulting: 'Consultoría tecnológica y arquitectura de software',
      security: 'Servicios de ciberseguridad y auditorías',
      ai: 'Integración de inteligencia artificial y machine learning'
    },
    responsibilities: {
      title: 'Responsabilidades del Usuario',
      content1: 'Como usuario de nuestros servicios, usted se compromete a:',
      accurate: 'Proporcionar información precisa y actualizada',
      compliance: 'Cumplir con todas las leyes y regulaciones aplicables',
      security: 'Mantener la seguridad de sus credenciales de acceso',
      prohibited: 'No utilizar nuestros servicios para actividades ilegales',
      cooperation: 'Cooperar en el desarrollo y testing de los proyectos'
    },
    payment: {
      title: 'Términos de Pago',
      quotes: 'Todos los precios se basan en cotizaciones personalizadas',
      methods: 'Aceptamos pagos por transferencia bancaria, tarjeta y PayPal',
      schedule: 'Los pagos se realizan según el cronograma acordado',
      late: 'Los pagos tardíos pueden incurrir en cargos adicionales',
      disputes: 'Las disputas de pago deben comunicarse dentro de 30 días'
    },
    intellectual: {
      title: 'Propiedad Intelectual',
      content1: 'Los derechos de propiedad intelectual se distribuyen de la siguiente manera:',
      ownership: {
        title: 'Propiedad de Activos',
        client: 'El cliente posee el código y contenido específico del proyecto',
        company: 'Borderless Techno posee herramientas y frameworks generales',
        thirdParty: 'Se respetan todos los derechos de terceros y licencias'
      }
    },
    privacy: {
      title: 'Privacidad y Confidencialidad',
      content1: 'Nos comprometemos a mantener la confidencialidad de su información:',
      confidential: 'Toda información del proyecto se trata como confidencial',
      disclosure: 'No divulgamos información sin su consentimiento explícito',
      protection: 'Implementamos medidas para proteger datos sensibles'
    },
    liability: {
      title: 'Limitación de Responsabilidad',
      content1: 'Nuestra responsabilidad está limitada de las siguientes maneras:',
      indirect: 'No somos responsables de daños indirectos o consecuentes',
      loss: 'No nos responsabilizamos por pérdida de datos del cliente',
      interruption: 'No garantizamos disponibilidad continua sin interrupciones',
      maximum: 'La responsabilidad máxima se limita al valor del contrato'
    },
    warranties: {
      title: 'Garantías',
      content1: 'Proporcionamos las siguientes garantías en nuestros servicios:',
      quality: 'Garantizamos la calidad del código y mejores prácticas',
      timeline: 'Nos comprometemos a cumplir con los plazos acordados',
      support: 'Ofrecemos soporte post-lanzamiento según el contrato',
      bugs: 'Corregimos errores identificados durante el período de garantía'
    },
    termination: {
      title: 'Terminación',
      content1: 'Estos términos pueden terminarse en las siguientes circunstancias:',
      convenience: 'Cualquier parte puede terminar con 30 días de aviso',
      breach: 'Terminación inmediata por incumplimiento material',
      effect: 'La terminación no afecta obligaciones ya contraídas'
    },
    law: {
      title: 'Ley Aplicable',
      content: 'Estos términos se rigen por las leyes de México. Cualquier disputa se resolverá en los tribunales competentes de Ciudad de México.'
    },
    changes: {
      title: 'Cambios a los Términos',
      content: 'Nos reservamos el derecho de modificar estos términos en cualquier momento. Los cambios entrarán en vigor al publicarse en nuestro sitio web.'
    },
    contact: {
      title: 'Información de Contacto',
      content: 'Para preguntas sobre estos Términos de Servicio, puede contactarnos:',
      company: 'Empresa',
      email: 'Email',
      address: 'Dirección'
    }
  },

  // Footer
  footer: {
    privacyPolicy: 'Política de Privacidad',
    termsOfService: 'Términos de Servicio'
  }
};